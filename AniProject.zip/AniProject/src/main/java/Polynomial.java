package main.java;

import java.util.ArrayList;

public class Polynomial {
	private ArrayList<Term> termList;
	public Polynomial(){
		termList = new ArrayList<Term>();
	}
	public void insertTerm(int coef, int exp){
		Term tempTerm = new Term(coef,exp);
		for (Term t: termList)
	 		if (exp > t.getExp()){
	 			termList.add(termList.indexOf(t),tempTerm);
	 			break;
	 		}
	 		else if(termList.indexOf(t) == termList.size()-1){
	 			termList.add(tempTerm);
	 			break;
	 		}
			if (termList.size() == 0)
				termList.add(tempTerm);
	}
	public void deleteTerm(int coef, int exp){
		for(Term tempTerm: termList){
			if ((tempTerm.getCoef() == coef) && (tempTerm.getExp() == exp)){
				termList.remove(termList.indexOf(tempTerm));
				break;
			}
		}
	}
	public void reverseTerms(){
		ArrayList<Term> tempList = new ArrayList<Term>();
		int listLength = termList.size() - 1;
		for (int i = 0; i <= listLength; listLength--){
			tempList.add(termList.get(listLength));
		}
		termList = tempList;
	}	
	public void printPoly(){
		for (Term t: termList){
			if (termList.indexOf(t) == 0)
				System.out.print(t);
			else
				System.out.print(" + " + t);
		}
	}
}
