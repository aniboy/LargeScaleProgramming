package main.java;

public class Term {
	private int coef;
	private int exp;
	public Term(int coef, int exp){
		setCoef(coef);
		setExp(exp);
	}
	public int getCoef() {
		return coef;
	}
	public void setCoef(int coef){
		this.coef = coef;
	}
	public int getExp() {
		return exp;
	}
	public void setExp(int exp){
		this.exp = exp;
	}
	public String toString(){
		if (exp == 0)
			return Integer.toString(coef);
		else if (exp == 1)
			return coef + "x" ;
		else
			return coef + "x^" + exp;
	}
}