
package test.java;

import main.java.Polynomial;

import java.io.*;
import java.util.*;

public class TestClass {
	static Polynomial poly; 
	public static void main(String[] args) throws IOException {
		int userIn;
		int num1 = 0, num2 = 0;
		poly = new Polynomial();
		Scanner stdin = new Scanner(System.in);
		FileInputStream fstream = new FileInputStream("src/test/infile.txt");
		  // Get the object of DataInputStream
		  DataInputStream in = new DataInputStream(fstream);
		  BufferedReader br = new BufferedReader(new InputStreamReader(in));
		  String strLine;
		  //Read File Line By Line
		  strLine = br.readLine();
		  strLine = strLine.substring(3, strLine.length());
		  String[] tokens = strLine.split(";");
		  for (int i = 0; i < tokens.length; i++){
			  if (i%2 == 0){
				 num1 = ( Integer.parseInt(tokens[i]));
			  }
			  else if(i%2 == 1){
				  num2 = (Integer.parseInt(tokens[i]));
				  poly.insertTerm(num1, num2);
			  }
		  }
		  br.close();
		do{
			System.out.println("\n\nChoose selection: ");
			System.out.println("1. Insert Term");
			System.out.println("2. Delete Term");
			System.out.println("3. Reverse Terms");
			System.out.println("4. Print Polynomial");
			System.out.println("5. Terminate Program\n");
			userIn = stdin.nextInt();
			if (userIn == 1){
				System.out.println("\nInsert Term");
				System.out.println("Enter coefficient, then exponent");
				num1 = stdin.nextInt();
				num2 = stdin.nextInt();
				poly.insertTerm(num1, num2);
				poly.printPoly();
			}
			else if (userIn == 2){
				System.out.println("\nDelete Term");
				System.out.println("Enter coefficient, then exponent");
				num1 = stdin.nextInt();
				num2 = stdin.nextInt();
				poly.deleteTerm(num1, num2);
				poly.printPoly();
			}
			else if (userIn == 3){
				System.out.println("\nReverse Terms");
				poly.reverseTerms();
				poly.printPoly();
			}
			else if(userIn == 4){
				System.out.println("\nPrint Polynomial");
				poly.printPoly();
			}
		}while (userIn != 5);
	}
}
